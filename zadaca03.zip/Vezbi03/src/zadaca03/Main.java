package zadaca03;

public class Main {

	public static void main(String[] args) {
		PC obj = new PC();
		
		obj.pecatiVrednosti(16, 500);
		
		
		
		
		
	}
	
	
	
}
