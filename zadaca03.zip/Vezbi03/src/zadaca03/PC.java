package zadaca03;

public class PC {
	
	public int memorija;
	public String tipNaMemorija;
	public int hardDisk;
	String golemina = "GB";
	
	public PC() {
		this.memorija = 2;
		this.tipNaMemorija = "DDR4";
		this.hardDisk = 256;
	}
	
	public void pecatiVrednosti(int zgolemiMemorija, int novHardDisk) {
		System.out.println("Memorijata bese " + this.memorija + " " + golemina + ", sega iznesuva " + (this.memorija + zgolemiMemorija) + " " + golemina + ".");                    
		System.out.println("Tipot na memorijata e " + this.tipNaMemorija + " " + golemina + ".");
		int HD = this.hardDisk + novHardDisk;
		System.out.println("HD ima golemina od " + HD + " " + golemina + ". Prethodno iznesuvase " + this.hardDisk + " " + golemina + ".");
		
		
		
		
		
	}
	
	
	
	

}
